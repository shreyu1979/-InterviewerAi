/* =========================================================
   DASHBOARD.JS
   tobeHired Dashboard
========================================================= */
console.log("🔥 DASHBOARD.JS LOADED");

/* =========================================================
   1. AUTH GUARD
========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    if (typeof authService === "undefined") {

        console.error("authService is not loaded.");

        window.location.href = "auth.html";

        return;
    }

    const currentUser =
        authService.getCurrentUser();

    if (!currentUser) {

        window.location.href = "auth.html";

        return;
    }

    const dashboardUserName =
        document.getElementById("dashboardUserName");

    if (dashboardUserName) {

        dashboardUserName.innerText =
            currentUser.name || "User";

    }

    window.scrollTo(0, 0);

});


/* =========================================================
   2. RESUME PDF UPLOAD + ANALYSIS
========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    const resumeInput =
        document.getElementById("resumeInput");

    const resumeResults =
        document.getElementById("resumeResults");

    const resumeResultsObserver =
        new MutationObserver(function () {

            console.log(
                "🚨🚨 resumeResults CHANGED"
            );

            console.log(
                "Display:",
                getComputedStyle(resumeResults).display
            );

            console.log(
                "Style:",
                resumeResults.getAttribute("style")
            );

        });

    resumeResultsObserver.observe(
        resumeResults,
        {
            attributes: true,
            childList: true,
            subtree: true
        }
    );

    const invalidResumeMessage =
        document.getElementById("invalidResumeMessage");

    const API_BASE_URL =
        "http://localhost:5000/api";


    console.log(
        "Resume upload system starting..."
    );


    if (!resumeInput) {

        console.error(
            "ERROR: #resumeInput was not found"
        );

        return;
    }


    if (!resumeResults) {

        console.error(
            "ERROR: #resumeResults was not found"
        );

        return;
    }


    if (!invalidResumeMessage) {

        console.error(
            "ERROR: #invalidResumeMessage was not found"
        );

        return;
    }


    /* =====================================================
       INITIAL STATE
    ===================================================== */

    resumeResults.style.display = "none";

    invalidResumeMessage.style.display = "none";


    /* =====================================================
       SHOW RESUME ERROR
    ===================================================== */

    function showResumeError(title, message) {

        resumeResults.style.setProperty(
            "display",
            "none",
            "important"
        );

        invalidResumeMessage.style.setProperty(
            "display",
            "block",
            "important"
        );

        invalidResumeMessage.innerHTML = `

            <div class="invalid-icon">

                <i class="bi bi-file-earmark-x"></i>

            </div>

            <h3>${title}</h3>

            <p>${message}</p>

            <button
                type="button"
                id="uploadAgainBtn"
            >

                <i class="bi bi-arrow-repeat"></i>

                Upload Another File

            </button>

        `;


        const newUploadButton =
            document.getElementById(
                "uploadAgainBtn"
            );


        if (newUploadButton) {

            newUploadButton.addEventListener(
                "click",
                function () {

                    resumeInput.value = "";

                    resumeInput.click();

                }
            );

        }

    }


    /* =====================================================
       DISPLAY RESUME ANALYSIS
    ===================================================== */

    function displayAnalysis(analysisResponse) {

        console.log(
            "🔥🔥 displayAnalysis() STARTED"
        );

        console.log(
            "🔥 ANALYSIS RESPONSE:",
            analysisResponse
        );


        let analysis =
            analysisResponse;


        if (
            analysisResponse &&
            analysisResponse.analysis
        ) {

            analysis =
                analysisResponse.analysis;

        }


        if (!analysis) {

            console.error(
                "No analysis object received."
            );

            return;

        }


        /* =================================================
           SHOW RESULT
        ================================================= */

        resumeResults.style.setProperty(
            "display",
            "block",
            "important"
        );

        invalidResumeMessage.style.setProperty(
            "display",
            "none",
            "important"
        );


        /* =================================================
           GET SKILLS
        ================================================= */

        let skills =
            analysis.skills;


        if (typeof skills === "string") {

            try {

                skills =
                    JSON.parse(skills);

            }

            catch (error) {

                skills =
                    [skills];

            }

        }


        if (!Array.isArray(skills)) {

            skills = [];

        }


        console.log(
            "Detected skills:",
            skills
        );


        /* =================================================
           DISPLAY DETECTED SKILLS
        ================================================= */

        const skillsList =
            resumeResults.querySelector(
                ".skills-list"
            );


        if (skillsList) {

            skillsList.innerHTML = "";


            if (skills.length > 0) {

                skills.forEach(
                    function (skill) {

                        const skillElement =
                            document.createElement(
                                "span"
                            );

                        skillElement.innerText =
                            skill;

                        skillsList.appendChild(
                            skillElement
                        );

                    }
                );

            }

            else {

                const noSkills =
                    document.createElement(
                        "span"
                    );

                noSkills.innerText =
                    "No specific skills detected";

                skillsList.appendChild(
                    noSkills
                );

            }

        }


        /* =================================================
           DISPLAY TEST SKILLS
        ================================================= */

        const testSkills =
            resumeResults.querySelector(
                ".test-skills"
            );


        if (testSkills) {

            testSkills.innerHTML = "";


            skills.forEach(
                function (skill) {

                    const skillElement =
                        document.createElement(
                            "span"
                        );


                    skillElement.innerText =
                        skill;


                    skillElement.style.cursor =
                        "pointer";


                    skillElement.classList.add(
                        "test-skill-card"
                    );


                    skillElement.dataset.skill =
                        skill.trim();


                    skillElement.addEventListener(
                        "click",
                        function () {

                            currentTestSkill =
                                skill.trim();


                            console.log(
                                "Selected test skill:",
                                currentTestSkill
                            );


                            const testButton =
                                document.getElementById(
                                    "startAptitudeTestBtn"
                                );


                            if (testButton) {

                                testButton.innerHTML = `

                                    Start
                                    ${currentTestSkill}
                                    Test

                                    <i class="bi bi-arrow-right"></i>

                                `;

                            }

                        }
                    );


                    testSkills.appendChild(
                        skillElement
                    );

                }
            );

        }


        /* =================================================
           EDUCATION
        ================================================= */

        let education =
            analysis.education;


        if (typeof education === "string") {

            try {

                education =
                    JSON.parse(education);

            }

            catch (error) {

                education =
                    [education];

            }

        }


        const educationList =
            resumeResults.querySelector(
                ".education-list"
            );


        if (educationList) {

            educationList.innerHTML = "";


            if (
                Array.isArray(education) &&
                education.length > 0
            ) {

                education.forEach(
                    function (item) {

                        const element =
                            document.createElement(
                                "span"
                            );

                        element.innerText =
                            item;

                        educationList.appendChild(
                            element
                        );

                    }
                );

            }

            else {

                educationList.innerHTML =
                    "<span>Not detected</span>";

            }

        }


        /* =================================================
           QUALIFICATION
        ================================================= */

        let qualification =
            analysis.qualification;


        if (typeof qualification === "string") {

            try {

                qualification =
                    JSON.parse(qualification);

            }

            catch (error) {

                qualification =
                    [qualification];

            }

        }


        const qualificationList =
            resumeResults.querySelector(
                ".qualification-list"
            );


        if (qualificationList) {

            qualificationList.innerHTML = "";


            if (
                Array.isArray(qualification) &&
                qualification.length > 0
            ) {

                qualification.forEach(
                    function (item) {

                        const element =
                            document.createElement(
                                "span"
                            );

                        element.innerText =
                            item;

                        qualificationList.appendChild(
                            element
                        );

                    }
                );

            }

            else {

                qualificationList.innerHTML =
                    "<span>Not detected</span>";

            }

        }


        /* =================================================
           FINAL DISPLAY
        ================================================= */

        console.log(
            "🟢 SHOWING resumeResults"
        );


        resumeResults.style.setProperty(
            "display",
            "block",
            "important"
        );


        invalidResumeMessage.style.setProperty(
            "display",
            "none",
            "important"
        );


        console.log(
            "resumeResults final style:",
            resumeResults.getAttribute("style")
        );


        console.log(
            "resumeResults computed display:",
            getComputedStyle(
                resumeResults
            ).display
        );


        console.log(
            "skills currently rendered:",
            resumeResults.querySelectorAll(
                ".skills-list span"
            ).length
        );


        console.log(
            "Resume analysis displayed successfully."
        );


        console.log("🚨 RESUME DISPLAY COMPLETE");
        console.log(
            "🚨 resumeResults display:",
            getComputedStyle(resumeResults).display
        );
        console.log(
            "🚨 resumeResults parent:",
            resumeResults.parentElement
        );
        console.log(
            "🚨 resumeResults HTML length:",
            resumeResults.innerHTML.length
        );

    }


    /* =====================================================
       UPLOAD + ANALYZE RESUME
    ===================================================== */

    async function uploadAndAnalyzeResume(file) {

        try {

            console.log(
                "Uploading resume:",
                file.name
            );


            if (
                typeof authService ===
                "undefined"
            ) {

                throw new Error(
                    "Authentication service is not available."
                );

            }


            const currentUser =
                authService.getCurrentUser();


            if (!currentUser) {

                throw new Error(
                    "Please log in before uploading your resume."
                );

            }


            const formData =
                new FormData();


            formData.append(
                "resume",
                file
            );


            formData.append(
                "user_id",
                currentUser.id
            );


            /* =================================================
               UPLOAD
            ================================================= */

            const uploadResponse =
                await fetch(
                    `${API_BASE_URL}/resume-analysis/upload`,
                    {
                        method: "POST",
                        body: formData
                    }
                );


            const uploadData =
                await uploadResponse.json();


            console.log(
                "Upload response:",
                uploadData
            );


            if (!uploadResponse.ok) {

                throw new Error(
                    uploadData.message ||
                    "Resume upload failed."
                );

            }


            const resumeId =
                uploadData.resume_id;


            if (!resumeId) {

                throw new Error(
                    "Resume uploaded but no resume ID was returned."
                );

            }


            /* =================================================
               ANALYZE
            ================================================= */

            const analyzeResponse =
                await fetch(
                    `${API_BASE_URL}/resume-analysis/analyze`,
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({

                            resume_id:
                                resumeId

                        })

                    }
                );


            const analyzeData =
                await analyzeResponse.json();


            console.log(
                "Analysis response:",
                analyzeData
            );


            if (!analyzeResponse.ok) {

                throw new Error(
                    analyzeData.message ||
                    "Resume analysis failed."
                );

            }


            console.log(
                "🔥 FRONTEND ANALYZE RESPONSE:",
                analyzeData
            );


            displayAnalysis(
                analyzeData
            );


            console.log(
                "Resume uploaded and analyzed successfully."
            );

        }

        catch (error) {

            console.error(
                "RESUME UPLOAD ERROR:",
                error
            );


            showResumeError(
                "Resume Processing Failed",
                error.message ||
                "Unable to process your resume. Please try again."
            );

        }

    }


    /* =====================================================
       FILE SELECTED
    ===================================================== */

    resumeInput.addEventListener(
        "change",
        async function (event) {
            console.log("🔥🔥 RESUME INPUT CHANGE EVENT FIRED 🔥🔥");

            event.preventDefault();


            const file =
                this.files[0];


            if (!file) {

                console.log(
                    "No file selected."
                );

                return;

            }


            console.log(
                "🔥 FILE SELECTED:",
                file.name
            );


            console.log(
                "🔥 FILE SIZE:",
                file.size
            );


            console.log(
                "🔥 FILE TYPE:",
                file.type
            );


            /* =================================================
               PDF VALIDATION
            ================================================= */

            const isPDF =
                file.type ===
                "application/pdf" ||
                file.name
                    .toLowerCase()
                    .endsWith(".pdf");


            if (!isPDF) {

                showResumeError(
                    "Invalid File",
                    "Please upload your resume in PDF format only."
                );


                this.value =
                    "";


                return;

            }


            /* =================================================
               5 MB LIMIT
            ================================================= */

            const maxSize =
                5 * 1024 * 1024;


            if (file.size > maxSize) {

                showResumeError(
                    "File Too Large",
                    "Please upload a PDF smaller than 5 MB."
                );


                this.value =
                    "";


                return;

            }


            /* =================================================
               HIDE OLD ERROR
            ================================================= */

            invalidResumeMessage.style.setProperty(
                "display",
                "none",
                "important"
            );


            /* =================================================
               PROCESS
            ================================================= */

            await uploadAndAnalyzeResume(
                file
            );

        }
    );


    /* =========================================================
       3. TEST VARIABLES
    ========================================================= */

    let javascriptQuestions = [];

    let currentTestSkill = null;

    let currentQuestion = 0;

    let selectedAnswer = null;

    let userAnswers = [];


    /* =========================================================
       4. TEST ELEMENTS
    ========================================================= */

    const questionText =
        document.getElementById(
            "questionText"
        );

    const liveOptions =
        document.getElementById(
            "liveOptions"
        );

    const questionNumber =
        document.getElementById(
            "questionNumber"
        );

    const liveProgress =
        document.getElementById(
            "liveProgress"
        );

    const nextQuestionBtn =
        document.getElementById(
            "nextQuestionBtn"
        );

    const answerMessage =
        document.getElementById(
            "answerMessage"
        );

    const liveTestBox =
        document.getElementById(
            "liveTestBox"
        );

    const liveResultBox =
        document.getElementById(
            "liveResultBox"
        );


    /* =========================================================
       5. SHOW QUESTION
    ========================================================= */

    function showQuestion() {

        if (
            !questionText ||
            !liveOptions ||
            !questionNumber ||
            !liveProgress
        ) {

            console.warn(
                "Live test elements were not found."
            );

            return;

        }


        if (
            !javascriptQuestions ||
            javascriptQuestions.length === 0
        ) {

            console.warn(
                "No questions available."
            );

            return;

        }


        const current =
            javascriptQuestions[
            currentQuestion
            ];


        if (!current) {

            return;

        }


        questionText.innerText =
            current.question;


        questionNumber.innerText =
            currentQuestion + 1;


        liveProgress.style.width =
            (
                (
                    (currentQuestion + 1) /
                    javascriptQuestions.length
                ) * 100
            ) + "%";


        liveOptions.innerHTML =
            "";


        selectedAnswer =
            null;


        if (answerMessage) {

            answerMessage.innerText =
                "Select an answer to continue";

        }


        const letters = [
            "A",
            "B",
            "C",
            "D"
        ];


        current.options.forEach(
            function (option, index) {

                const optionElement =
                    document.createElement(
                        "div"
                    );


                optionElement.classList.add(
                    "live-option"
                );


                optionElement.innerHTML = `

                    <span class="live-option-letter">
                        ${letters[index]}
                    </span>

                    <span>
                        ${option}
                    </span>

                `;


                optionElement.addEventListener(
                    "click",
                    function () {

                        document
                            .querySelectorAll(
                                ".live-option"
                            )
                            .forEach(
                                function (item) {

                                    item.classList.remove(
                                        "selected"
                                    );

                                }
                            );


                        optionElement.classList.add(
                            "selected"
                        );


                        selectedAnswer =
                            index;


                        if (answerMessage) {

                            answerMessage.innerText =
                                "Answer selected";

                        }

                    }
                );


                liveOptions.appendChild(
                    optionElement
                );

            }
        );


        if (nextQuestionBtn) {

            if (
                currentQuestion ===
                javascriptQuestions.length - 1
            ) {

                nextQuestionBtn.innerHTML = `

                    Submit Test

                    <i class="bi bi-check-lg"></i>

                `;

            }

            else {

                nextQuestionBtn.innerHTML = `

                    Next Question

                    <i class="bi bi-arrow-right"></i>

                `;

            }

        }

    }


    /* =========================================================
       6. START TEST FOR ANY SKILL
    ========================================================= */

    async function startSkillTest(skill) {

        if (!skill) {

            console.error(
                "No skill supplied."
            );

            return;

        }


        try {

            currentTestSkill =
                skill.trim();


            console.log(
                "Starting test for:",
                currentTestSkill
            );


            const response =
                await fetch(
                    `http://localhost:5000/api/questions/random?skill=${encodeURIComponent(currentTestSkill)}&limit=20`
                );


            const data =
                await response.json();


            console.log(
                "Questions API response:",
                data
            );


            if (
                !data.success ||
                !data.questions ||
                data.questions.length === 0
            ) {

                alert(
                    `No questions found for ${currentTestSkill}.`
                );

                return;

            }


            javascriptQuestions =
                data.questions.map(
                    function (question) {

                        return {

                            id:
                                question.id,

                            question:
                                question.question,

                            options: [

                                question.option_a,

                                question.option_b,

                                question.option_c,

                                question.option_d

                            ],

                            correct:
                                [
                                    "A",
                                    "B",
                                    "C",
                                    "D"
                                ].indexOf(
                                    String(
                                        question.correct_answer
                                    )
                                        .trim()
                                        .toUpperCase()
                                )

                        };

                    }
                );


            currentQuestion =
                0;


            selectedAnswer =
                null;


            userAnswers =
                [];


            if (liveResultBox) {

                liveResultBox.style.display =
                    "none";

            }


            if (liveTestBox) {

                liveTestBox.style.display =
                    "block";

            }


            showQuestion();


            if (liveTestBox) {

                liveTestBox.scrollIntoView({

                    behavior:
                        "smooth",

                    block:
                        "start"

                });

            }

        }

        catch (error) {

            console.error(
                "Skill test error:",
                error
            );


            alert(
                "Unable to load questions. Please try again."
            );

        }

    }


    /* =========================================================
       7. SKILL CARD CLICK
    ========================================================= */

    function attachSkillCardListeners() {

        const skillCards =
            document.querySelectorAll(
                ".test-skill-card"
            );


        skillCards.forEach(
            function (card) {

                card.addEventListener(
                    "click",
                    function () {

                        const skill =
                            card.dataset.skill;


                        if (!skill) {

                            return;

                        }


                        startSkillTest(
                            skill
                        );

                    }
                );

            }
        );

    }


    attachSkillCardListeners();


    /* =========================================================
       8. START APTITUDE TEST
    ========================================================= */

    const startAptitudeTestBtn =
        document.getElementById(
            "startAptitudeTestBtn"
        );


    if (startAptitudeTestBtn) {

        startAptitudeTestBtn.addEventListener(
            "click",
            async function () {

                console.log(
                    "Starting Aptitude Test..."
                );


                await startSkillTest(
                    "Aptitude"
                );

            }
        );

    }


    /* =========================================================
       9. NEXT QUESTION
    ========================================================= */

    if (nextQuestionBtn) {

        nextQuestionBtn.addEventListener(
            "click",
            function () {

                if (
                    selectedAnswer === null
                ) {

                    if (answerMessage) {

                        answerMessage.innerText =
                            "Please select an answer first";

                    }

                    return;

                }


                userAnswers.push(
                    selectedAnswer
                );


                if (
                    currentQuestion <
                    javascriptQuestions.length - 1
                ) {

                    currentQuestion++;

                    showQuestion();

                }

                else {

                    showResults();

                }

            }
        );

    }


    /* =========================================================
       10. SHOW TEST RESULTS
    ========================================================= */

    async function showResults() {

        console.log(
            "================================="
        );

        console.log(
            "TEST COMPLETED"
        );

        console.log(
            "================================="
        );


        let correctAnswers =
            0;


        const answerReviewList =
            document.getElementById(
                "answerReviewList"
            );


        if (answerReviewList) {

            answerReviewList.innerHTML =
                "<p>Loading your results...</p>";

        }


        const results =
            [];


        try {

            for (
                let index = 0;
                index < javascriptQuestions.length;
                index++
            ) {

                const question =
                    javascriptQuestions[index];


                const selectedAnswerIndex =
                    userAnswers[index];


                const answerLetters = [
                    "A",
                    "B",
                    "C",
                    "D"
                ];


                const userAnswer =
                    selectedAnswerIndex !== undefined
                        ? answerLetters[
                        selectedAnswerIndex
                        ]
                        : "";


                console.log(
                    "Submitting question:",
                    question.id,
                    "Answer:",
                    userAnswer
                );


                const response =
                    await fetch(
                        "http://localhost:5000/api/questions/submit",
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json"
                            },

                            body: JSON.stringify({

                                questionId:
                                    question.id,

                                answer:
                                    userAnswer

                            })

                        }
                    );


                const data =
                    await response.json();


                console.log(
                    "Result response:",
                    data
                );


                if (
                    !response.ok ||
                    !data.success
                ) {

                    throw new Error(
                        data.message ||
                        "Unable to check answer."
                    );

                }


                results.push(
                    data
                );


                if (data.correct) {

                    correctAnswers++;

                }

            }


            const wrongAnswers =
                javascriptQuestions.length -
                correctAnswers;


            const scorePercentage =
                Math.round(
                    (
                        correctAnswers /
                        javascriptQuestions.length
                    ) * 100
                );


            const finalScore =
                document.getElementById(
                    "finalScore"
                );


            const scoreCircle =
                document.querySelector(
                    ".score-circle strong"
                );


            const correctCount =
                document.getElementById(
                    "correctCount"
                );


            const wrongCount =
                document.getElementById(
                    "wrongCount"
                );


            if (finalScore) {

                finalScore.innerText =
                    correctAnswers +
                    " / " +
                    javascriptQuestions.length;

            }


            if (scoreCircle) {

                scoreCircle.innerText =
                    scorePercentage + "%";

            }


            if (correctCount) {

                correctCount.innerText =
                    correctAnswers;

            }


            if (wrongCount) {

                wrongCount.innerText =
                    wrongAnswers;

            }


            if (answerReviewList) {

                answerReviewList.innerHTML =
                    "";

            }


            results.forEach(
                function (result, index) {

                    const reviewItem =
                        document.createElement(
                            "div"
                        );


                    reviewItem.classList.add(
                        "review-item"
                    );


                    if (result.correct) {

                        reviewItem.classList.add(
                            "correct"
                        );

                    }

                    else {

                        reviewItem.classList.add(
                            "wrong"
                        );

                    }


                    reviewItem.innerHTML = `

                        <div class="review-question">

                            ${index + 1}.
                            ${result.question}

                        </div>


                        <div class="review-answer">

                            <strong>
                                Your Answer:
                            </strong>

                            ${result.userAnswer || "Not answered"}

                            <br>


                            <strong>
                                Correct Answer:
                            </strong>

                            ${result.correctAnswerText}

                            <br><br>


                            <strong>
                                Explanation:
                            </strong>

                            <p>
                                ${result.explanation}
                            </p>

                        </div>

                    `;


                    if (answerReviewList) {

                        answerReviewList.appendChild(
                            reviewItem
                        );

                    }

                }
            );


            if (liveTestBox) {

                liveTestBox.style.display =
                    "none";

            }


            if (liveResultBox) {

                liveResultBox.style.display =
                    "block";


                liveResultBox.scrollIntoView({

                    behavior:
                        "smooth",

                    block:
                        "start"

                });

            }


            console.log(
                "Test results displayed successfully."
            );

        }

        catch (error) {

            console.error(
                "RESULT PROCESSING ERROR:",
                error
            );


            if (answerReviewList) {

                answerReviewList.innerHTML = `

                    <p>
                        Unable to load your test results.
                    </p>

                `;

            }

        }

    }


    /* =========================================================
       11. RESTART TEST
    ========================================================= */

    const restartTestBtn =
        document.getElementById(
            "restartTestBtn"
        );


    if (restartTestBtn) {

        restartTestBtn.addEventListener(
            "click",
            function () {

                currentQuestion =
                    0;


                selectedAnswer =
                    null;


                userAnswers =
                    [];


                if (liveResultBox) {

                    liveResultBox.style.display =
                        "none";

                }


                if (liveTestBox) {

                    liveTestBox.style.display =
                        "block";

                }


                showQuestion();

            }
        );

    }


    /* =========================================================
       12. TEST UI READY
    ========================================================= */

    if (
        questionText &&
        liveOptions &&
        questionNumber &&
        liveProgress
    ) {

        console.log(
            "Test UI ready."
        );

    }


    /* =========================================================
       13. LOGOUT
    ========================================================= */

    function logout() {

        if (
            typeof authService !==
            "undefined" &&
            typeof authService.logout ===
            "function"
        ) {

            authService.logout();

        }

        else {

            localStorage.removeItem(
                "currentUser"
            );

            localStorage.removeItem(
                "user"
            );

            localStorage.removeItem(
                "token"
            );

        }


        window.location.href =
            "auth.html";

    }


    /* =========================================================
       14. FEEDBACK FORM
    ========================================================= */

    console.log(
        "Feedback form starting..."
    );


    const feedbackForm =
        document.getElementById(
            "feedbackForm"
        );


    const nameInput =
        document.getElementById(
            "name"
        );


    const emailInput =
        document.getElementById(
            "email"
        );


    const typeInput =
        document.getElementById(
            "type"
        );


    const subjectInput =
        document.getElementById(
            "subject"
        );


    const messageInput =
        document.getElementById(
            "message"
        );


    const feedbackStatus =
        document.getElementById(
            "feedbackStatus"
        );


    if (feedbackForm) {

        /* =====================================================
           AUTO-FILL USER
        ===================================================== */

        if (
            typeof authService !==
            "undefined" &&
            typeof authService.getCurrentUser ===
            "function"
        ) {

            const currentUser =
                authService.getCurrentUser();


            console.log(
                "🔐 AUTH CHECK:",
                currentUser
            );


            if (currentUser) {

                if (
                    nameInput &&
                    currentUser.name
                ) {

                    nameInput.value =
                        currentUser.name;

                }


                if (
                    emailInput &&
                    currentUser.email
                ) {

                    emailInput.value =
                        currentUser.email;

                }

            }

        }


        /* =====================================================
           SUBMIT FEEDBACK
        ===================================================== */

        feedbackForm.addEventListener(
            "submit",
            async function (event) {

                event.preventDefault();


                const name =
                    nameInput.value.trim();


                const email =
                    emailInput.value.trim();


                const type =
                    typeInput.value;


                const subject =
                    subjectInput.value.trim();


                const message =
                    messageInput.value.trim();


                if (
                    !name ||
                    !email ||
                    !type ||
                    !subject ||
                    !message
                ) {

                    feedbackStatus.textContent =
                        "Please fill in all fields.";


                    feedbackStatus.style.color =
                        "red";


                    return;

                }


                feedbackStatus.textContent =
                    "Submitting feedback...";


                feedbackStatus.style.color =
                    "";


                const submitButton =
                    feedbackForm.querySelector(
                        ".feedback-submit"
                    );


                if (submitButton) {

                    submitButton.disabled =
                        true;


                    submitButton.textContent =
                        "Submitting...";

                }


                try {

                    const response =
                        await fetch(
                            "http://localhost:5000/api/feedback",
                            {
                                method: "POST",

                                headers: {
                                    "Content-Type":
                                        "application/json"
                                },

                                body: JSON.stringify({

                                    name:
                                        name,

                                    email:
                                        email,

                                    type:
                                        type,

                                    subject:
                                        subject,

                                    message:
                                        message

                                })

                            }
                        );


                    const data =
                        await response.json();


                    console.log(
                        "Feedback API response:",
                        data
                    );


                    if (!response.ok) {

                        throw new Error(
                            data.message ||
                            "Failed to submit feedback."
                        );

                    }


                    feedbackStatus.textContent =
                        data.message ||
                        "Thank you! Your feedback has been submitted successfully.";


                    feedbackStatus.style.color =
                        "green";


                    feedbackForm.reset();


                    /* =================================================
                       RESTORE USER INFORMATION
                    ================================================= */

                    if (
                        typeof authService !==
                        "undefined" &&
                        typeof authService.getCurrentUser ===
                        "function"
                    ) {

                        const currentUser =
                            authService.getCurrentUser();


                        if (currentUser) {

                            if (
                                nameInput &&
                                currentUser.name
                            ) {

                                nameInput.value =
                                    currentUser.name;

                            }


                            if (
                                emailInput &&
                                currentUser.email
                            ) {

                                emailInput.value =
                                    currentUser.email;

                            }

                        }

                    }

                }

                catch (error) {

                    console.error(
                        "Feedback submission error:",
                        error
                    );


                    feedbackStatus.textContent =
                        error.message ||
                        "Unable to submit feedback. Please try again.";


                    feedbackStatus.style.color =
                        "red";

                }

                finally {

                    if (submitButton) {

                        submitButton.disabled =
                            false;


                        submitButton.textContent =
                            "Submit Report";

                    }

                }

            }
        );

    }

    else {

        console.warn(
            "Feedback form not found."
        );

    }


    console.log(
        "Feedback form ready."
    );

});